#Assigning values to variables
x<-10
y<-"Hello Sohail, This is your first R Program...."

print(x)
print(y)


#Basic Arithmetic operation
a <- 5+10
b <- 10-5
c <- 10*2
d <- 10/2
e <- 5%%2


#Logical Operators

a = TRUE
b = FALSE
print(a&b)
print(a|b)
print(!a)


# Taking User Input
name<-readline(prompt = "Enter your Name: ")
age<-as.numeric(readline(prompt = "Enter your age: "))

if(!is.na(age)){
  print(paste("Your Name is", name, "& Your age is ", age))
}else{
  print("You not entered a numberical age.")
}

# Practice Data_structure 
name_vec<- c("Sohail", "Aslam","Sheraz")
age_vec<- c(21,45,23)

print(name_vec[3])
print(age_vec)

#Practice Matrix
num_matrix<- matrix(10:18, nrow=3, ncol=3)
print(num_matrix)

#Practice List
my_list = list(name="Sohail", age = "21", num_vec = c(21,22,23,24,25))
print(my_list$name)
print(my_list$num_vec)

#Practice Data Frame
mydata = data.frame(ID = c(1,2,3), Name = c("Sohail", "Aslam", ""))

