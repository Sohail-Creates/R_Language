# ========================================
# Task 1: Find the Greatest Common Divisor (GCD)
# ========================================

# Function to compute the GCD (Greatest Common Divisor) of two numbers
find_gcd <- function(a, b) {
  while (b != 0) {  # Continue until remainder becomes 0
    temp <- b       # Store b in a temporary variable
    b <- a %% b     # Update b with the remainder of a divided by b
    a <- temp       # Update a with the previous value of b
  }
  return(a)  # Return the GCD
}

# Test Cases for GCD Function
print(find_gcd(48, 18))  # Expected Output: 6
print(find_gcd(56, 98))  # Expected Output: 14
print(find_gcd(101, 103))  # Expected Output: 1 (since 101 and 103 are prime)

# ========================================
# Task 2: Generate First N Prime Numbers
# ========================================

# Helper function to check if a number is prime
is_prime <- function(num) {
  if (num < 2) return(FALSE)  # Numbers less than 2 are not prime
  for (i in 2:sqrt(num)) {  # Check divisibility up to the square root of num
    if (num %% i == 0) return(FALSE)  # If divisible, it's not prime
  }
  return(TRUE)  # If no divisors found, it's prime
}

# Function to generate the first N prime numbers
generate_primes <- function(n) {
  primes <- c()  # Initialize an empty vector to store prime numbers
  num <- 2  # Start checking from the smallest prime number
  
  while (length(primes) < n) {  # Continue until we find N primes
    if (is_prime(num)) {  # Check if the number is prime
      primes <- c(primes, num)  # Add prime number to the list
    }
    num <- num + 1  # Move to the next number
  }
  return(primes)  # Return the list of prime numbers
}

# Test Cases for Prime Number Generation
print(generate_primes(5))  # Expected Output: 2, 3, 5, 7, 11
print(generate_primes(10)) # Expected Output: 2, 3, 5, 7, 11, 13, 17, 19, 23, 29
print(generate_primes(1))  # Expected Output: 2 (First prime number)
