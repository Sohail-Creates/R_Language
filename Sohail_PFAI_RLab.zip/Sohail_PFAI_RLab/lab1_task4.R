# ========================================
# Task 1: Load and View the mtcars Dataset
# ========================================

# Load the built-in mtcars dataset
data(mtcars)

# Display the first few rows of the dataset
print(head(mtcars))  # Shows first 6 rows for a quick overview

# ========================================
# Task 2: Calculate Statistics for MPG Column
# ========================================

# Compute mean (average) of MPG (Miles per Gallon)
mean_mpg <- mean(mtcars$mpg)

# Compute median (middle value) of MPG
median_mpg <- median(mtcars$mpg)

# Compute standard deviation (spread of values) of MPG
sd_mpg <- sd(mtcars$mpg)

# Display the calculated values
print(paste("Mean MPG:", mean_mpg))  # Expected Output: 20.09 (approx)
print(paste("Median MPG:", median_mpg))  # Expected Output: 19.2 (approx)
print(paste("Standard Deviation of MPG:", sd_mpg))  # Expected Output: 6.03 (approx)

# ========================================
# Task 3: Create a Subset of Cars with MPG > 20
# ========================================

# Filter the dataset to include only rows where MPG > 20
subset_mtcars <- subset(mtcars, mpg > 20)

# Display the subsetted dataset
print(subset_mtcars)  # Shows only cars with fuel efficiency greater than 20 MPG
