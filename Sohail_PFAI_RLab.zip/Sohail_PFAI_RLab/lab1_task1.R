# ==============================================
# Task 1: Create a Data Frame for Student Marks
# ==============================================

# Creating a data frame with 5 students and their marks in 3 subjects
students <- data.frame(
  Name = c("Ali", "Sara", "Sohail", "Aisha", "Mohsin"),  # Student Names
  Math = c(80, 90, 85, 70, 88),      # Marks in Mathematics
  Science = c(75, 88, 92, 65, 80),   # Marks in Science
  English = c(78, 85, 80, 72, 83)    # Marks in English
)

# ==============================================
# Task 2: Calculate Total and Average Marks
# ==============================================

# Calculating total marks for each student
students$Total <- students$Math + students$Science + students$English

# Calculating average marks (Total Marks divided by 3 subjects)
students$Average <- students$Total / 3

# ==============================================
# Task 3: Display the Final Table
# ==============================================

# Printing the final table with all student marks, total, and average
print(students)
