# ========================================
# Task 1: Check if a Number is Even or Odd
# ========================================

# Function to check if a number is even or odd
check_even_odd <- function(num) {
  if (num %% 2 == 0) {  # If remainder is 0 when divided by 2, it's even
    print(paste(num, "is Even"))  
  } else {  
    print(paste(num, "is Odd"))  
  }
}

# Test Cases for Even/Odd Function
check_even_odd(10)  # Expected Output: 10 is Even
check_even_odd(7)   # Expected Output: 7 is Odd
check_even_odd(0)   # Expected Output: 0 is Even (special case)
check_even_odd(-3)  # Expected Output: -3 is Odd (negative numbers work too)

# ========================================
# Task 2: Check if a Number is Prime
# ========================================

# Function to check if a number is prime
is_prime <- function(num) {
  if (num < 2) {  # Numbers less than 2 are not prime
    return(FALSE)  
  }
  for (i in 2:sqrt(num)) {  # Optimized: Check divisibility only up to sqrt(num)
    if (num %% i == 0) {  
      return(FALSE)  # If divisible, it's not a prime number
    }
  }
  return(TRUE)  # If no divisors found, it's prime
}

# Test Cases for Prime Function
print(is_prime(7))   # Expected Output: TRUE (7 is Prime)
print(is_prime(10))  # Expected Output: FALSE (10 is Not Prime)
print(is_prime(2))   # Expected Output: TRUE (2 is the smallest prime)
print(is_prime(1))   # Expected Output: FALSE (1 is not prime)
print(is_prime(97))  # Expected Output: TRUE (97 is Prime)
print(is_prime(100)) # Expected Output: FALSE (100 is Not Prime)

