# ============================================
# Task 1: Filtering Even Numbers from a Vector
# ============================================

# Function to filter even numbers from a given vector
filter_even_numbers <- function(vec) {
  return(vec[vec %% 2 == 0])  # Select numbers that are exactly divisible by 2
}

# Test Cases for Even Number Filtering
print(filter_even_numbers(c(1, 2, 3, 4, 5, 6)))  # Expected Output: 2, 4, 6
print(filter_even_numbers(c(7, 9, 11, 12, 14)))  # Expected Output: 12, 14
print(filter_even_numbers(c(10, 15, 20, 25)))   # Expected Output: 10, 20

# ============================================
# Task 2: Palindrome Number Check
# ============================================

# Function to check if a number is a palindrome
is_palindrome <- function(num) {
  str_num <- as.character(num)  # Convert number to string
  rev_str <- paste(rev(strsplit(str_num, "")[[1]]), collapse = "")  # Reverse string correctly
  return(str_num == rev_str)  # Compare original and reversed string
}

# Test Cases for Palindrome Check
print(is_palindrome(121))  # Expected Output: TRUE
print(is_palindrome(123))  # Expected Output: FALSE
print(is_palindrome(1441)) # Expected Output: TRUE
print(is_palindrome(98789)) # Expected Output: TRUE
print(is_palindrome(1001)) # Expected Output: TRUE
