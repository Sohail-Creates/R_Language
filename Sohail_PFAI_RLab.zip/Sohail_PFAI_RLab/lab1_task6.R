# ============================
# Data Visualization using ggplot2
# ============================

# Load necessary library (Ensure ggplot2 is installed)
library(ggplot2)

# Load built-in mtcars dataset
data(mtcars)  # Ensures dataset is available

# ===========================================
# Task 1: Scatter Plot of MPG vs Horsepower
# ===========================================
plot1 <- ggplot(mtcars, aes(x = hp, y = mpg)) +  # Set x-axis as horsepower, y-axis as MPG
  geom_point() +  # Add scatter points
  labs(title = "MPG vs Horsepower",  # Add title
       x = "Horsepower",  # Label for x-axis
       y = "Miles per Gallon (MPG)")  # Label for y-axis

# Display the plot
print(plot1)  # Ensures plot is shown when script runs

# ===========================================
# Task 2: Customized Scatter Plot
# ===========================================
plot2 <- ggplot(mtcars, aes(x = hp, y = mpg)) +  # Set x and y axes
  geom_point(color = "blue", size = 3) +  # Change point color and size
  labs(title = "Fuel Efficiency vs Power",  # Title for the plot
       x = "Horsepower",  # X-axis label
       y = "Miles per Gallon") +  # Y-axis label
  theme_minimal()  # Apply a clean theme

# Display the customized plot
print(plot2)  # Ensures plot appears
