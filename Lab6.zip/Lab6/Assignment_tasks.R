
#install.packages(c("ROSE", "DMwR2", "caret", "rpart", "ggplot2", "smotefamily"))

#-----------------------------Load each package with a comment describing its purpose-----------------------------

library(smotefamily)
library(ROSE)        # For random oversampling to balance classes
library(DMwR2)       # For SMOTE (Synthetic Minority Oversampling Technique)
library(caret)       # For model training, cross-validation, and performance evaluation
library(rpart)       # For training decision tree models
library(ggplot2)     # For visualizations (if needed)
library(pROC)        # For Roc and AUC curve

#-----------------------------Check for is these packages installed or not-------------------------------------

installed <- c("ROSE", "DMwR2", "caret", "rpart", "ggplot2", "UBL")
installed[installed %in% rownames(installed.packages())]


#-----------------------------Create Imbalanced Iris Dataset-----------------------------

# Load Iris Dataset and Create Imbalance
data <- iris  # Load built-in iris dataset

set.seed(123)  # Set seed for reproducibility

# Keep only 20% of the setosa rows
setosa_part <- data[data$Species == "setosa", ]
setosa_sample <- setosa_part[sample(1:nrow(setosa_part), size = round(0.2 * nrow(setosa_part))), ]

# Keep all rows from the other two species
non_setosa <- data[data$Species != "setosa", ]

# Combine them to create the imbalanced dataset
imbalanced_data <- rbind(non_setosa, setosa_sample)

# Step 4.1 – Convert to binary classification (Setosa = 1, Others = 0)
binary_data <- imbalanced_data  # Start from imbalanced data

# Create a new binary target variable
binary_data$Label <- ifelse(binary_data$Species == "setosa", 1, 0)

# Remove the original Species column
binary_data$Species <- NULL

# Check class distribution
table(binary_data$Label)

#-----------------------------Oversample the Minority Class (Using ROSE)-----------------------------

# Apply Random Oversampling to Balance the Classes
set.seed(123)  # Set seed for reproducibility

# Perform both over-sampling and under-sampling to create a balanced dataset
rose_balanced <- ovun.sample(Label ~ ., data = binary_data, method = "both", N = 150)$data

# Check the new class distribution after ROSE (it should be balanced)
table(rose_balanced$Label)

# Train a decision tree classifier using the balanced dataset (Setosa vs Others)
model <- rpart(Label ~ ., data = rose_balanced, method = "class")

# Display the decision tree summary
summary(model)

# Plot the tree to visualize the decision-making process
plot(model)
text(model, use.n = TRUE, all = TRUE, cex = 0.8)




#-----------------------------Evaluate Model Performance with a Confusion Matrix-----------------------------

# Obtain predictions from the trained model
predictions <- predict(model, rose_balanced, type = "class")

# Convert predictions and actual labels to factors with the same levels
predictions <- factor(predictions, levels = c(0, 1))  # 0 for Others, 1 for Setosa
rose_balanced$Label <- factor(rose_balanced$Label, levels = c(0, 1))

# Evaluate using confusion matrix
conf_matrix <- confusionMatrix(predictions, rose_balanced$Label)

# Print confusion matrix
print(conf_matrix)

# Check performance metrics like accuracy, sensitivity, specificity, etc.
print(paste("Accuracy: ", conf_matrix$overall['Accuracy']))
print(paste("Sensitivity: ", conf_matrix$byClass['Sensitivity']))
print(paste("Specificity: ", conf_matrix$byClass['Specificity']))


#--------------------------Visualize the Performance with the ROC Curve and AUC--------------------------


# Predict probabilities for the positive class (Setosa)
probabilities <- predict(model, rose_balanced, type = "prob")

# ROC curve
roc_curve <- roc(rose_balanced$Label, probabilities[,2])

# Plot ROC curve
plot(roc_curve, main = "ROC Curve for Decision Tree")

# Print AUC (Area Under Curve)
print(paste("AUC: ", auc(roc_curve)))



#--------------------------Tune the Model -------------------------



# Define a grid of hyperparameters for tuning the decision tree
tune_grid <- expand.grid(cp = seq(0.01, 0.1, by = 0.01))

# Perform cross-validation to tune the model
tuned_model <- train(Label ~ ., data = rose_balanced, method = "rpart", tuneGrid = tune_grid, trControl = trainControl(method = "cv"))

# Best tuned parameters
print(tuned_model$bestTune)

# Retrain the model with the best parameters
best_model <- rpart(Label ~ ., data = rose_balanced, method = "class", cp = tuned_model$bestTune$cp)

# Evaluate the tuned model
best_predictions <- predict(best_model, rose_balanced, type = "class")
best_conf_matrix <- confusionMatrix(best_predictions, rose_balanced$Label)
print(best_conf_matrix)



#--------------------------Use varImp() from caret for Feature Importance-------------------------

# Use caret's varImp function to calculate feature importance
feature_importance <- varImp(model, scale = FALSE)

# Print feature importance
print(feature_importance)


#-------------------------- Plot the Decision Tree-------------------------

# Plot the tree to visualize the decision-making process
plot(model)
text(model, use.n = TRUE, all = TRUE, cex = 0.8)
